#include "delay.h"
#include "wifi.h"
#include "usart1.h"
#include "station.h"
#include "timer.h"


uint8_t Step=0;
int time_wifi=10;
char WIFI_status(uint8_t *name, uint8_t *pass)
{

	delay_ms(200);
	switch(Step)
	{
		case 0:
			u1_printf("����ģʽ\r\n");//�˳�͸��ģʽ
			u2_printf("+++");
			Step=1;
			break;
		
		case 1: 
			u2_printf("AT+CWMODE=1\r\n");
			u1_printf("����ģʽ\r\n");
		  Step=2;
		  time_wifi=10;
		break;
		case 2:
			if(strstr(Usart2_RxBuff,"OK") != NULL)
			{
				Step = 3;			
				wifi_close();
			}
		  else
			{
				if(time_wifi <= 0)
				{
					
					Step = 1;
					wifi_close();
				}
			}
			break;
		case 3:
			u2_printf("AT+RST\r\n\r\n");
			u1_printf("��λ\r\n");
			Step=4;
			time_wifi=10;
			break;
		case 4:
			if(strstr(Usart2_RxBuff,"OK") != NULL)
			{
				Step = 5;
				wifi_close();
			}
		  else
			{
			
				if(time_wifi <= 0)
				{
					Step = 3;wifi_close();
				}
			}
			break;
		case 5:
			u2_printf("ATE0\r\n\r\n");
			u1_printf("�ػ���\r\n");
			Step=6;
			time_wifi=10;
			break;
		case 6:
			if(strstr(Usart2_RxBuff,"OK") != NULL)
			{
				Step = 7;
				wifi_close();
			}
		  else
			{
			
				if(time_wifi <= 0)
				{
					wifi_close();
					Step = 5;
				}
			}
			break;
		case 7:
			u2_printf("AT+CWQAP\r\n\r\n");
			u1_printf("�Ͽ�IP����\r\n");
			Step=8;
			time_wifi=10;
			break;
		case 8:
			if(strstr(Usart2_RxBuff,"OK") != NULL)
			{
				Step = 9;
				wifi_close(); 
			}
		  else
			{
			
				if(time_wifi <= 0)
				{
					wifi_close();
					Step = 7;
				}
			}
			break;	
		case 9:
			WiFi_printf("AT+CWJAP=\"%s\",\"%s\"\r\n",name,pass);;
			u1_printf("����WIFI\r\n");
			Step=10;
			time_wifi=10;
			break;
		case 10:
			if(strstr(Usart2_RxBuff,"GOT IP") != NULL)
			{
				Step = 11;
				u1_printf("����WIFI�ɹ�\r\n");				
	      wifi_close();
			}
		  else
			{

				if(time_wifi <= 0)
				{
					wifi_close();
					Step = 9;
					return 1;
				}
			}
			break;
		
		case 11:
			WiFi_printf("AT+CIPSTART=\"TCP\",\"192.168.137.1\",8080\r\n");;
			u1_printf("����IP\r\n");
			Step=12;
			time_wifi=10;
			break;
		case 12:
			if(strstr(Usart2_RxBuff,"CONNECT") != NULL)
			{
				Step = 13;
				u1_printf("����IP�ɹ�\r\n");		
				wifi_close();
			}
		  else
			{
				if(time_wifi <= 0)
				{
					wifi_close();
					Step = 11;
				}
			}
			break;	
		
		case 13: 
			delay_ms(100);
			u2_printf("AT+CIPMODE=1\r\n");
			u1_printf("����͸��ģʽ\r\n");
		  Step=14;
		  time_wifi=10;
			break;
		case 14:
			if(strstr(Usart2_RxBuff,"OK") != NULL)
			{
				Step = 15;
				wifi_close(); 
			}
		  else
			{
			
				if(time_wifi <= 0)
				{
					wifi_close();
					Step = 13;
				}
			}
			break;
			
		case 15:
			WiFi_printf("AT+CIPSEND\r\n");;
			u1_printf("����͸��ģʽ\r\n");
			Step=16;
			time_wifi=10;
			break;
		case 16:
			if(strstr(Usart2_RxBuff,">") != NULL)
			{
				Step = 0xff;
				WiFi_RxCounter=0;                                 //WiFi������������������ 
				u1_printf("����͸��ģʽ�ɹ�\r\n");				
	      memset(WiFi_RX_BUF,0,WiFi_RXBUFF_SIZE);           //���WiFi���ջ����� 
			}
		  else
			{
				if(time_wifi <= 0)
					Step = 15;
			}
			break;


		case 0xff:
		{
			;
		}break;
		
		
	}
	return 0;
}


//��ʱ��7�жϷ������		    
void TIM7_IRQHandler(void)
{ 	
	static unsigned int count=0;
	if (TIM_GetITStatus(TIM7, TIM_IT_Update) != RESET)//�Ǹ����ж�
	{	 
		count++;
		if(count>=40)
		{
			count=0;
			time_wifi--;
		}
		TIM_ClearITPendingBit(TIM7, TIM_IT_Update  );  //���TIM7�����жϱ�־ 
	}	    
}
