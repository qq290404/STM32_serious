#ifndef _station_H
#define _station_H
#include "stm32f10x.h"

extern unsigned char Step;
extern int time_wifi;
char WIFI_status(uint8_t *name, uint8_t *pass);
#endif
