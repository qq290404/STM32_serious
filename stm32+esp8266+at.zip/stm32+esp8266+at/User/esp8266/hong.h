#ifndef _hong_H
#define _hong_H


#define T_Close 			0

#define Set_AP_Mode_0 1
#define Set_AP_Mode_1 2
#define RST_WIFI_0 		3
#define RST_WIFI_1 		4
#define Set_AP_0 			5
#define Set_AP_1 			6
#define Set_AP_Par_0 	7
#define Set_AP_Par_1 	8
#define Close_UT_0 		9
#define Close_UT_1 		10
#define Open_Mux_0 		11
#define Open_Mux_1 		12
#define Open_Ser_0 		13
#define Open_Ser_1		14
#define Start_T_0 		15
#define Start_T_1			16
#define Open_T_0 			17
#define Open_T_1			18
#endif


